from textual.widgets._input import Selection

__all__ = ["Selection"]
