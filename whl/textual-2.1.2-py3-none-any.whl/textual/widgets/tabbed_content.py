from textual.widgets._tabbed_content import ContentTab, ContentTabs

__all__ = [
    "ContentTab",
    "ContentTabs",
]
